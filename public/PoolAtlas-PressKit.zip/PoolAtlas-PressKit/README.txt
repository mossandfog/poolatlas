POOL ATLAS — PRESS KIT
======================

Contents:
  Logos/poolatlas-logotype-color.png  — Primary logo, for light backgrounds
  Logos/poolatlas-logotype-white.png  — White logo, for dark backgrounds
  PoolAtlas-FactSheet.pdf             — Press fact sheet

For additional assets or media inquiries: hello@poolatlas.io
poolatlas.io
